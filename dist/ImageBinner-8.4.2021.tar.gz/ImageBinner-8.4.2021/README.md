# ImageBinner


## To install the package run:




## Literature



## Web
For more information visit:

http://share.smb.uni-frankfurt.de

https://github.com/JohannaRahm
